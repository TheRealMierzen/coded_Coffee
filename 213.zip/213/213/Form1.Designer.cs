﻿namespace _213
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExit = new System.Windows.Forms.Button();
            this.saleBtn = new GaryPerkin.UserControls.Buttons.RoundButton();
            this.roundButton2 = new GaryPerkin.UserControls.Buttons.RoundButton();
            this.roundButton3 = new GaryPerkin.UserControls.Buttons.RoundButton();
            this.stockBtn = new GaryPerkin.UserControls.Buttons.RoundButton();
            this.TechBtn = new GaryPerkin.UserControls.Buttons.RoundButton();
            this.hqBtn = new GaryPerkin.UserControls.Buttons.RoundButton();
            this.button1 = new System.Windows.Forms.Button();
            this.txtname = new System.Windows.Forms.TextBox();
            this.txtpass = new System.Windows.Forms.TextBox();
            this.txtauth = new System.Windows.Forms.TextBox();
            this.txtauthpass = new System.Windows.Forms.TextBox();
            this.txtlvl = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(9, 9);
            this.btnExit.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(50, 24);
            this.btnExit.TabIndex = 0;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.button1_Click_1);
            this.btnExit.MouseEnter += new System.EventHandler(this.button1_MouseEnter);
            // 
            // saleBtn
            // 
            this.saleBtn.BackColor = System.Drawing.Color.White;
            this.saleBtn.Location = new System.Drawing.Point(472, 94);
            this.saleBtn.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.saleBtn.Name = "saleBtn";
            this.saleBtn.RecessDepth = 0;
            this.saleBtn.Size = new System.Drawing.Size(104, 102);
            this.saleBtn.TabIndex = 1;
            this.saleBtn.Text = "Sale";
            this.saleBtn.UseVisualStyleBackColor = false;
            this.saleBtn.Click += new System.EventHandler(this.saleButton_Click);
            this.saleBtn.MouseEnter += new System.EventHandler(this.saleButton_MouseEnter);
            this.saleBtn.MouseLeave += new System.EventHandler(this.saleButton_MouseLeave);
            // 
            // roundButton2
            // 
            this.roundButton2.BackColor = System.Drawing.Color.White;
            this.roundButton2.Location = new System.Drawing.Point(472, 587);
            this.roundButton2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.roundButton2.Name = "roundButton2";
            this.roundButton2.RecessDepth = 0;
            this.roundButton2.Size = new System.Drawing.Size(104, 102);
            this.roundButton2.TabIndex = 2;
            this.roundButton2.Text = "End of day";
            this.roundButton2.UseVisualStyleBackColor = false;
            this.roundButton2.Click += new System.EventHandler(this.roundButton2_Click);
            // 
            // roundButton3
            // 
            this.roundButton3.BackColor = System.Drawing.Color.White;
            this.roundButton3.Location = new System.Drawing.Point(688, 233);
            this.roundButton3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.roundButton3.Name = "roundButton3";
            this.roundButton3.RecessDepth = 0;
            this.roundButton3.Size = new System.Drawing.Size(104, 102);
            this.roundButton3.TabIndex = 3;
            this.roundButton3.Text = "Orders";
            this.roundButton3.UseVisualStyleBackColor = false;
            this.roundButton3.Click += new System.EventHandler(this.roundButton3_Click);
            // 
            // stockBtn
            // 
            this.stockBtn.BackColor = System.Drawing.Color.White;
            this.stockBtn.Location = new System.Drawing.Point(262, 428);
            this.stockBtn.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.stockBtn.Name = "stockBtn";
            this.stockBtn.RecessDepth = 0;
            this.stockBtn.Size = new System.Drawing.Size(104, 102);
            this.stockBtn.TabIndex = 4;
            this.stockBtn.Text = "Stock";
            this.stockBtn.UseVisualStyleBackColor = false;
            this.stockBtn.Click += new System.EventHandler(this.roundButton4_Click);
            // 
            // TechBtn
            // 
            this.TechBtn.BackColor = System.Drawing.Color.White;
            this.TechBtn.Location = new System.Drawing.Point(688, 428);
            this.TechBtn.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.TechBtn.Name = "TechBtn";
            this.TechBtn.RecessDepth = 0;
            this.TechBtn.Size = new System.Drawing.Size(104, 102);
            this.TechBtn.TabIndex = 5;
            this.TechBtn.Text = "Technical";
            this.TechBtn.UseVisualStyleBackColor = false;
            this.TechBtn.Click += new System.EventHandler(this.roundButton5_Click);
            // 
            // hqBtn
            // 
            this.hqBtn.BackColor = System.Drawing.Color.White;
            this.hqBtn.Location = new System.Drawing.Point(262, 233);
            this.hqBtn.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.hqBtn.Name = "hqBtn";
            this.hqBtn.RecessDepth = 0;
            this.hqBtn.Size = new System.Drawing.Size(104, 102);
            this.hqBtn.TabIndex = 6;
            this.hqBtn.Text = "Headquarters";
            this.hqBtn.UseVisualStyleBackColor = false;
            this.hqBtn.Click += new System.EventHandler(this.roundButton6_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(13, 47);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 7;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_2);
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(95, 47);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(100, 22);
            this.txtname.TabIndex = 8;
            // 
            // txtpass
            // 
            this.txtpass.Location = new System.Drawing.Point(95, 76);
            this.txtpass.Name = "txtpass";
            this.txtpass.Size = new System.Drawing.Size(100, 22);
            this.txtpass.TabIndex = 9;
            // 
            // txtauth
            // 
            this.txtauth.Location = new System.Drawing.Point(95, 105);
            this.txtauth.Name = "txtauth";
            this.txtauth.Size = new System.Drawing.Size(100, 22);
            this.txtauth.TabIndex = 10;
            // 
            // txtauthpass
            // 
            this.txtauthpass.Location = new System.Drawing.Point(95, 134);
            this.txtauthpass.Name = "txtauthpass";
            this.txtauthpass.Size = new System.Drawing.Size(100, 22);
            this.txtauthpass.TabIndex = 11;
            // 
            // txtlvl
            // 
            this.txtlvl.Location = new System.Drawing.Point(202, 47);
            this.txtlvl.Name = "txtlvl";
            this.txtlvl.Size = new System.Drawing.Size(100, 22);
            this.txtlvl.TabIndex = 12;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = global::_213.Properties.Resources._48992;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
//<<<<<<< HEAD
            this.ClientSize = new System.Drawing.Size(1500, 922);
            this.Controls.Add(this.txtlvl);
            this.Controls.Add(this.txtauthpass);
            this.Controls.Add(this.txtauth);
            this.Controls.Add(this.txtpass);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.button1);
//=======
            this.ClientSize = new System.Drawing.Size(1028, 609);
//>>>>>>> 80ebbc421a7914617e2b44f5901e06ce1be75a7f
            this.Controls.Add(this.hqBtn);
            this.Controls.Add(this.TechBtn);
            this.Controls.Add(this.stockBtn);
            this.Controls.Add(this.roundButton3);
            this.Controls.Add(this.roundButton2);
            this.Controls.Add(this.saleBtn);
            this.Controls.Add(this.btnExit);
            this.DoubleBuffered = true;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form1";
            this.Text = "stock.IT";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnExit;
        private GaryPerkin.UserControls.Buttons.RoundButton saleBtn;
        private GaryPerkin.UserControls.Buttons.RoundButton roundButton2;
        private GaryPerkin.UserControls.Buttons.RoundButton roundButton3;
        private GaryPerkin.UserControls.Buttons.RoundButton stockBtn;
        private GaryPerkin.UserControls.Buttons.RoundButton TechBtn;
        private GaryPerkin.UserControls.Buttons.RoundButton hqBtn;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.TextBox txtpass;
        private System.Windows.Forms.TextBox txtauth;
        private System.Windows.Forms.TextBox txtauthpass;
        private System.Windows.Forms.TextBox txtlvl;
    }
}

